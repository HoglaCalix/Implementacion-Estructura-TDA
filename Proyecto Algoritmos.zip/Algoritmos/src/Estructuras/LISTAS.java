package Estructuras;

/**
 * Definición de TDA "LISTA".
 * 
 * @param <T> tipo de elementos contenidos por la lista
 * @author paul.rinaudo@unah.hn
 * @version 1.0.0
 */
public interface LISTAS<T> {
	/**
	 * Devuelve el índice del primer elemento due la lista.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @return índice del primer elemento de la lista.
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	default int PRIMERO() {
		return 1;
	}
	/**
	 * Devuelve el índice del siguiente elemento nulo.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @return índice del siguiente elemento nulo.
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	int FIN();
	/**
	 * Indica si la lista está o no vacía.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @return {@code true} si la lista está vacía.
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean VACIA();
	/**
	 * Intenta agregar un elemento dentro de la lista, en un índice arbitrario.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @param x elemento por agregar
	 * @param p índice del nuevo elemento
	 * @return {@code true} si se pudo agregar el elemento exitosamente
	 * 	o {@code false} si {@code x} está vacío ó {@code p} no es una posición válida en la lista
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean INSERTA(T x, int p);
	/**
	 * Intenta suprimir un elemento dentro de la lista, en un índice arbitrario.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @param p índice del elemento a suprimir
	 * @return {@code true} si se pudo suprimir el elemento indicado exitosamente
	 * 	o {@code false} si {@code p} no es una posición válida en la lista
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean SUPRIME(int p);
	/**
	 * Devuelve el elemento contenido por la lista en un índice arbitrario.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @param p índice del elemento por recuperar
	 * @return elemento en la posición {@code p}, o {@code null} si la {@code p} no es una posición válida
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	T RECUPERA(int p);
	/**
	 * Suprime todos los elementos de la lista.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	void ANULA();
	/**
	 * Devuelve el índice correspondiente a la primera ocurrencia de un elemento.
	 * 
	 * @param x elemento por localizar
	 * @return índice de la primera ocurrencia de {@code x} ó -1 si este no existe.
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	int LOCALIZA(T x);
	/**
	 * Devuelve el índice posterior a otro índice arbitrario.
	 * 
	 * @param p índice objetivo
	 * @return el índice posterior si este es válido en la lista, ó -1 de lo contrario.
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	int SIGUIENTE(int p);
	/**
	 * Devuelve el índice previo a otro índice arbitrario.
	 * 
	 * @param p índice objetivo
	 * @return el índice previo si este es válido en la lista, ó -1 de lo contrario.
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	int ANTERIOR(int p);
}
