package Estructuras;

/**
 * Definición de TDA Cola.
 * 
 * @param <T> tipo de elementos contenidos por la cola
 * @author paul.rinaudo@unah.hn
 * @version 1.0.0
 */
public interface COLAS<T> {
	/**
	 * Suprime todos los elementos de la cola.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	void ANULA();
	/**
	 * Devuelve el elemento al frente de la cola.
	 * 
	 * @return elemento al frente de la cola
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	T FRENTE();
	/**
	 * Adiciona un elemento al final de la cola
	 * 
	 * @param x elemento por meter
	 * @return {@code true} si {@code x} no es nulo.
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean PONE_EN_COLA(T x);
	/**
	 * Suprime el elemento al frente de la cola
	 * 
	 * @return {@code true} si la cola no está vacía
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean QUITA_DE_COLA();
	/**
	 * Indica si la cola se encuentra vacía
	 * 
	 * @return {@code true} si la cola está vacía
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean VACIA();
}
