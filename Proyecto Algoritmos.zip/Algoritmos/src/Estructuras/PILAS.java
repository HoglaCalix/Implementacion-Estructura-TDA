package Estructuras;

/**
 * Definición de TDA PILA.
 * 
 * @param <T> Tipo de elementos contenidos en la pila.
 * @author paul.rinaudo@unah.hn
 * @version 1.0.0
 */
public interface PILAS<T> {
	/**
	 * Devuelve el elemento al tope de la pila.
	 * 
	 * @return elemento al tope de la pila
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	T TOPE();
	/**
	 * Adiciona un elemento al tope de la pila
	 * 
	 * @param x elemento por meter
	 * @return {@code true} si {@code x} no es nulo.
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean METE(T x);
	/**
	 * Suprime el elemento al tope de la pila
	 * 
	 * @param x elemento por meter
	 * @return {@code true} si {@code x} no es nulo.
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean SACA();
	/**
	 * Indica si la pila se encuentra vacía
	 * 
	 * @return {@code true} si la pila está vacía
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean VACIA();
	/**
	 * Suprime todos los elementos de la pila.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	boolean ANULA();
}
