package programLibraries;
import Implementaciones.Lista;
import Implementaciones.Cola;
import Implementaciones.Pila;

public class Program {

	 /**
	 *
	 *Demuestra todas las operaciones de las TDA Lista, Cola y Pila junto con ejemplos de sus implementaciones.	
	 *
	 * @author hogla.calix@unah.hn
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
		public static void main(String[] args) {
			System.out.println("ºDemostracion de Listas.");
			System.out.println("");
			
			/**
			 * Demostracion de operaciones de Lista
			 */
			
			Lista<String> lista = new Lista<String>();
			System.out.println("-Demostracion de INSERTA en una lista en final.");
			lista.INSERTA_FINAL("4");
			System.out.println(lista.toString());
			lista.INSERTA_FINAL("7");
			System.out.println(lista.toString());
			lista.INSERTA_FINAL("12");
			System.out.println(lista.toString());
			System.out.println("-Demostracion de INSERTA en Primero");
			lista.INSERTA_PRIMERO("8");
			System.out.println(lista.toString());
			lista.INSERTA_PRIMERO("90");
			System.out.println(lista.toString());
			lista.INSERTA_PRIMERO("24");
			System.out.println(lista.toString());
			System.out.println("");
			
			System.out.println("-Demostracion de SUPRIME");
			System.out.println("Suprime el valor en la posicion 5");
			lista.SUPRIME(5);
			System.out.println(lista.toString());
			System.out.println("");
			
			System.out.println("-Demostracion de SIGUIENTE y ANTERIOR");
			System.out.println("El valor en la posicion SIGUIENTE a la posicion 4");
			
			System.out.println(lista.RECUPERA(lista.SIGUIENTE(4)));
			System.out.println("");
			System.out.println("El valor en la posicion ANTERIOR a la posicion 4");
			
			System.out.println(lista.RECUPERA(lista.ANTERIOR(4)));
			System.out.println("");
			
		
			
			System.out.println("");
			System.out.println("-Demostracion de LOCALIZA");
			System.out.println(lista.toString());
			System.out.println("Localiza 12");
			System.out.println(lista.LOCALIZA("12"));
			
			System.out.println("");
			System.out.println("-Demostracion de RECUPERA");
			System.out.println(lista.toString());
			System.out.println("Recupera elemento en la posicion 3");
			System.out.println(lista.RECUPERA(3));
			
			
			/**
			 * Demostracion de operaciones de Lista
			 */
			
			System.out.println("");
			System.out.println("ºDemostracion de operaciones de pilas");
			System.out.println("");
			
			
			
			Pila<String> pila = new Pila<>();
			
			System.out.println("-Demostracion METE");
			pila.METE("3");
			System.out.println("Mete 2");
			pila.METE("2");
			System.out.println(pila.toString());
			System.out.println("Mete 4");
			pila.METE("4");
			System.out.println(pila.toString());
			System.out.println("Mete 120");
			pila.METE("120");
			System.out.println(pila.toString());
			System.out.println("");
			System.out.println("-Demostracion TOPE");
		
			System.out.println(pila.TOPE());
			System.out.println("");
			
			
		
			System.out.println("-Demostracion SACA");
			System.out.println(pila.toString());
			pila.SACA();
			System.out.println(pila.toString());
			pila.SACA();
			System.out.println(pila.toString());
			pila.SACA();
			System.out.println(pila.toString());
			pila.SACA();
			System.out.println(pila.toString());
			System.out.println("");
			 
			
			
			/**
			 * Demostracion de operaciones de Lista
			 */
			
			System.out.println("ºDemostracion de Colas");
			Cola<String> cola = new Cola<>();
			System.out.println("");
			System.out.println("-Demostracion metodo PONE_EN_COLA");
			cola.PONE_EN_COLA("3");
			System.out.println(cola.toString());
			cola.PONE_EN_COLA("2");
			System.out.println(cola.toString());
			cola.PONE_EN_COLA("5");
			System.out.println(cola.toString());
			System.out.println("");
			
			System.out.println("-Demostracion metodo FRENTE");
			System.out.println(cola.FRENTE());
			System.out.println("");
			
			System.out.println("-Demostracion metodo QUITE_DE_COLA");
			System.out.println(cola.toString());
			cola.QUITA_DE_COLA();
			System.out.println(cola.toString());
			cola.QUITA_DE_COLA();
			System.out.println(cola.toString());
			cola.QUITA_DE_COLA();
			System.out.println(cola.toString());
			System.out.println("");
			
			
			/**
			 * Ejemplo de las implementaciones de Pila.
			 */
			
			Lista<String> lista2 = new Lista<String>();
			Pila<String> pila2 = new Pila<>();
			System.out.println("Invertir una lista usando Pilas.");
			lista2.INSERTA_FINAL("4");
			lista2.INSERTA_FINAL("7");
			lista2.INSERTA_FINAL("12");
			lista2.INSERTA_PRIMERO("8");
			lista2.INSERTA_PRIMERO("90");
			lista2.INSERTA_PRIMERO("24");
			System.out.println(lista2.toString());
			
			
			while(!lista2.VACIA()) {
				pila2.METE(lista2.RECUPERA_PRIMERO());
				lista2.SUPRIME(lista2.PRIMERO());
				
			}
			
			while(!pila2.VACIA()) {
				lista2.INSERTA(pila2.TOPE(), lista2.FIN());
				pila2.SACA();
				
			}
			
			System.out.println(lista2.toString());
			
			
			
	
			}
			
}
		
			
		
		
		
		
		
		


