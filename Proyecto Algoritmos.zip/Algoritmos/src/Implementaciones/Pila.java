package Implementaciones;


/**
 * implementación de TDA PILA utilizando operaciones de Lista.
 * 
 * @param <T> tipo de elementos que contiene
 * @author paul.rinaudo@unah.hn hogla.calix@unah.hn
 * @version 1.0.0
 */
public class Pila<T extends Comparable<T>> {
    private Lista<T> lista;

    /**
	 *
	 *Crea una pila que se comporta como Lista
	 *
	 * @author paul.rinaudo@unah.hn hogla.calix@unah.hn
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
    public Pila() {
        lista = new Lista<>();
    }

    /**
	 *
	 *Inserta el elemento T en el TOPE de la pila. Siendo este el primero de la lista.
	 *
	 * @author paul.rinaudo@unah.hn hogla.calix@unah.hn
	 * @param T elemento de tipo generico
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
    public void METE(T elemento) {
        lista.INSERTA_PRIMERO(elemento);
    }

    /**
	 *
	 *Elimina el elemento T del tope de la pila que se encuentra en primero de lista.
	 *
	 * @author paul.rinaudo@unah.hn hogla.calix@unah.hn
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
    public T SACA() {
        if (lista.VACIA()) {
            System.out.println("Pila vacía");
            return null;
        }
        T elemento = lista.RECUPERA_PRIMERO();
        lista.SUPRIME(lista.PRIMERO());
        return elemento;
    }

    /**
	 *
	 *Lee el elemento en el TOPE de la Pila mostrando el contenido de este
	 *
	 * @author paul.rinaudo@unah.hn hogla.calix@unah.hn
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
    public T TOPE() {
        if (lista.VACIA()) {
            System.out.println("Pila vacía");
            return null;
        }
        return lista.RECUPERA_PRIMERO();
    }

    /**
	 *
	 *Retorna veradero si la Pila se encuentra vacia
	 *
	 * @author paul.rinaudo@unah.hn hogla.calix@unah.hn
	
	 * @return boolean
	 * @version 1.0.0
	 * @since 1.0.0
	 */
    public boolean VACIA() {
        return lista.VACIA();
    }

    /**
	 *
	 Elimina los elementos de la Pila
	 *
	 * @author paul.rinaudo@unah.hn hogla.calix@unah.hn
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */

    public void ANULA() {
        lista.ANULA();
    }

    /**
	 *
	 *Retorna la version texto de la Pila
	 *
	 * @author paul.rinaudo@unah.hn hogla.calix@unah.hn
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
    @Override
    public String toString() {
        return lista.toString();
    }

}
