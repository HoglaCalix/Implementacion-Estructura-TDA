package Implementaciones;

import Estructuras.COLAS;

/**
 * implementación de TDA COLA con lista de apuntadores.
 * 
 * @param <T> tipo de elementos que contiene
 * @author paul.rinaudo@unah.hn 
 * @version 1.0.0
 */
public class Cola<T extends Comparable<T>> implements COLAS<T> {
	private Lista<T> fuente;
	

    /**
	 *
	 *Crea una cola la cual se comporta como una lista 
	 *
	 * @author paul.rinaudo@unah.hn 
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	public Cola() {
		fuente = new Lista<T>();
	}


    /**
	 *
	 *Verifica si la Cola se enceuntra vacia
	 *
	 * @author paul.rinaudo@unah.hn 
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public void ANULA() {
		fuente.ANULA();
	}


    /**
	 *
	 *Retorna el contenido en el frente de la cola 
	 *
	 * @author paul.rinaudo@unah.hn 
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public T FRENTE() {
		return fuente.RECUPERA_PRIMERO();
	}

	/**
	 *
	 *Inserta el elemento x en el Frente de la cola 
	 *
	 * @author paul.rinaudo@unah.hn 
	 * @param x elemento de insertar
	 * @return boolean 
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public boolean PONE_EN_COLA(T x) {
		return fuente.INSERTA_FINAL(x);
	}

	/**
	 *
	 *Elimina el elemento al frente de la cola.	 
	 *
	 * @author paul.rinaudo@unah.hn 
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public boolean QUITA_DE_COLA() {
		return fuente.SUPRIME(fuente.PRIMERO());
	}

	/**
	 *
	 *Retorna verdadero si la cola se encuentra vacia
	 *
	 * @author paul.rinaudo@unah.hn 
	 * @return boolean
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public boolean VACIA() {
		return fuente.VACIA();
	}
	/**
	 *
	 *Retorna la version texto de la cola
	 *
	 * @author paul.rinaudo@unah.hn 
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public String toString() {
		return fuente.toString();
		
	}

}