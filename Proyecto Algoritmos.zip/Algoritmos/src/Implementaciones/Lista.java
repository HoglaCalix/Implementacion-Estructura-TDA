package Implementaciones;

import Estructuras.LISTAS;


/**
 * implementación de TDA LISTA con apuntadores.
 * 
 * @param <T> tipo de elementos que contiene
 * @author paul.rinaudo@unah.hn
 * @version 1.0.0
 */
public class Lista<T extends Comparable<T>> implements LISTAS<T> {
	private int cuenta = 0;
	private Nodo cabeza = new Nodo();
	private Nodo cola = cabeza;
	
	public Lista() {
	}
	/**
	 * 
	 * Retorna el numero de elementos que se encuentran en la lista +1
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @return cuenta +1
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public int FIN() {
		return cuenta + 1;
	}

	
	/**
	 *
	 *Retorna verdadero si la cuenta o cantidad de elementos en la lista es igual a 0
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @param p posicion
	 * @return p+1
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public boolean VACIA() {
		return cuenta == 0;
	}

	
	/**
	 *
	 *Inserta el valor x en la posicion p de la lista creando un nodo con el contenido a insertar y colocando un cursor en la cabeza 
	 *de la lista. El ciclo se detiene justo antes de la posicion deseada al nuevo nodo se le establece la posicion siguiente del cursor y al cursor se le establece la siguiente 
	 *posicion del nodo.
	 *
	 * @author paul.rinaudo@unah.hn
	 * @param p posicion y x elemento a insertar
	 * @return verdadero
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public boolean INSERTA(T x, int p) {
		if (p < PRIMERO() || p > FIN())
			return false;
		if (p == FIN())
			return INSERTA_FINAL(x);
		if (x == null)
			return false;
		
		Nodo nuevoNodo = new Nodo(x);
		Nodo cursor = cabeza;
		for (int i = 1; i < p; i++)
			cursor = cursor.siguiente();
		nuevoNodo.estableceSiguiente(cursor.siguiente());
		cursor.estableceSiguiente(nuevoNodo);
		cuenta++;
		return true;
	}
	
	
	/**
	 *
	 *Elimina el contenido dentro del nodo en la posicion p. Se establece un nodo cursor en la cabeza de la lista y recorre hasta la posicion anterior a p. Si la cola 
	 *es igual a la siguiente posicion de cursor es decir p este establece la cola como un nodo vacio sin contenido.
	 *
	 * @author paul.rinaudo@unah.hn
	 * @param p posicion 
	 * @return verdadero
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public boolean SUPRIME(int p) {
		if (p < PRIMERO() || p > ANTERIOR(FIN()))
			return false;
		
		Nodo cursor = cabeza;
		for (int i = 1; i < p; i++)
			cursor = cursor.siguiente();
		if (cola == cursor.siguiente())
			cola = cursor;
		cursor.estableceSiguiente(cursor.siguiente().siguiente());
		cuenta--;
		return true;
	}

	/**
	 *
	 *Retorna el contenido dentro del nodo en la posicion p. Dicho nodo recorre hasta llegar a la posicion p.
	 *
	 * @author paul.rinaudo@unah.hn
	 * @param p posicion
	 * @return contenido del cursor 
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public T RECUPERA(int p) {
		if (p < PRIMERO() || p > ANTERIOR(FIN()))
			return null;
		if (p == PRIMERO()) return RECUPERA_PRIMERO();
		if (p == ANTERIOR(FIN())) return RECUPERA_ULTIMO();
		Nodo cursor = cabeza;
		for (int i = 1; i <= p; i++)
			cursor = cursor.siguiente();
		return cursor.contenido();
	}

	/**
	 *Elimina los elementos de la lista apuntando la cabeza a null y estableciendo la cuenta nuevamente en 0. 
	 * @author paul.rinaudo@unah.hn
	 * @return void
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public void ANULA() {
		cabeza.estableceSiguiente(null);
		cuenta = 0;
	}
	/**
	 * Compara el elemento enviado con el contenido en el cursor si este retorna verdadero o 0 este nos retorna el indice donde se encuentra el cursor. 
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @return indice o -1
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public int LOCALIZA(T x) {
		if (x == null) return -1;
		Nodo cursor = cabeza.siguiente();
		int indice = 1;
		while (cursor != null) {
			if (cursor.contenido().compareTo(x) == 0)
				return indice;
			cursor= cursor.siguiente();
			indice++;
		}
		return -1;
	}
	
	/**
	 * 
	 * Retorna el numero de la posicion enviada +1
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @param p posicion
	 * @return p+1
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public int SIGUIENTE(int p) {
		if (p == FIN())
			return -1;
		return p + 1;
	}
	
	/**
	 * 
	 * Retorna el numero de la posicion enviada -1
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @param p posicion
	 * @return p+1
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	@Override
	public int ANTERIOR(int p) {
		if (p == PRIMERO())
			return -1;
		return p - 1;
	}
	
	/**
	 * Intenta agregar un elemento al principio de la lista.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @param x elemento por agregar
	 * @return {@code true} si se pudo agregar el elemento exitosamente
	 * 	o {@code false} si {@code x} está vacío
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	public boolean INSERTA_PRIMERO(T x) {
		return INSERTA(x, PRIMERO());
	}
	/**
	 * Intenta agregar un elemento al final de la lista.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @param x elemento por agregar
	 * @return {@code true} si se pudo agregar el elemento exitosamente
	 * 	o {@code false} si {@code x} está vacío
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	public boolean INSERTA_FINAL(T x) {
		if (x == null) return false;
		Nodo nuevoNodo = new Nodo(x);
		cola.estableceSiguiente(nuevoNodo);
		cola = nuevoNodo;
		cuenta++;
		return true;
	}
	
	/**
	 * Devuelve el primer elemento de la lista.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @return primer elemento de la lista, ó {@code null} si lista está vacía
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	public T RECUPERA_PRIMERO() {
		if (VACIA()) return null;
		return cabeza.siguiente().contenido();
	}
	/**
	 * Devuelve el último elemento de la lista.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @return último elemento de la lista, ó {@code null} si lista está vacía
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	public T RECUPERA_ULTIMO() {
		return cola.contenido();
	}
	/**
	 * Devuelve la versión texto de la lista.
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @return último elemento de la lista, ó {@code null} si lista está vacía
	 * @version 1.1.0
	 * @since 1.1.0
	 */
	@Override
	public String toString () {
		if (VACIA())
			return "[ ]";
		Nodo cursor = cabeza.siguiente();
		StringBuilder builder = new StringBuilder(String.format("[ %s", cursor.contenido()));
		cursor = cursor.siguiente();
		while (cursor != null) {
			builder.append(String.format(", %s", cursor.contenido()));
			cursor = cursor.siguiente();			
		}
		builder.append(" ]");
		return builder.toString();
	}
	
	
	/**
	 * Estructura auxiliar mediante la cual se compone la lista enlazada. Cada elemento y una referencia al siguiente elemento
	 * 
	 * @author paul.rinaudo@unah.hn
	 * @version 1.0.0
	 * @since 1.0.0
	 */
	private class Nodo {
		private T contenido;
		private Nodo siguiente = null;
		
		public Nodo() {
			this.contenido = null;
		}
		
		public Nodo(T contenido) {
			this.contenido = contenido;
		}
		
		/**
		 * Expone el elemento en el nodo a la lista enlazada.
		 * @return elemento dentro del nodo
		 * @author paul.rinaudo@unah.hn
		 * @version 1.0.0
		 * @since 1.0.0
		 */
		public T contenido() {
			return this.contenido;
		}
		/**
		 * Expone siguiente nodo a la lista enlazada.
		 * @return siguiente nodo
		 * @author paul.rinaudo@unah.hn
		 * @version 1.0.0
		 * @since 1.0.0
		 */
		public Nodo siguiente() {
			return this.siguiente;
		}
		/**
		 * Establece el nodo al que apunta el nodo local.
		 * @param n referencia del siguiente nodo
		 * @author paul.rinaudo@unah.hn
		 * @version 1.0.0
		 * @since 1.0.0
		 */
		public void estableceSiguiente(Nodo n) {
			this.siguiente = n;
		}
	}
	
	
}
